/* ============================================================
   PRODIG — homepage interactions & animations (vanilla)
   ============================================================ */
(function () {
  "use strict";

  /* ---------- icon set (lucide-style paths) ---------- */
  var ICON = {
    cap: '<path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c0 1 2.5 2.5 6 2.5s6-1.5 6-2.5v-5"/>',
    palette: '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2Z"/>',
    book: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    type: '<polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/>',
    sparkles: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"/><path d="M19 15l.9 2.4L22 18l-2.1.6L19 21l-.9-2.4L16 18l2.1-.6L19 15Z"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>'
  };
  function svg(paths) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + paths + '</svg>';
  }

  /* ---------- data ---------- */
  var CATEGORIES = [
    { label: "Course & Tutorial", icon: "cap" },
    { label: "Template Desain Grafis", icon: "palette" },
    { label: "E-Book", icon: "book" },
    { label: "Preset & Filter", icon: "sliders" },
    { label: "Printable & Planner", icon: "calendar" },
    { label: "Font & Typography", icon: "type" },
    { label: "AI Prompt Pack", icon: "sparkles" },
    { label: "Lainnya", icon: "grid" }
  ];

  var U = function (id, w) { return "https://images.unsplash.com/photo-" + id + "?w=" + (w || 600) + "&q=80&auto=format&fit=crop"; };

  var PRODUCTS = [
    { title: "Template Laporan Keuangan UMKM Excel", cat: "Spreadsheet", seller: "Andi Pratama", price: 50000, img: "1554224155-6726b3ff858f" },
    { title: "50 Preset Lightroom Moody Cinematic", cat: "Preset & Filter", seller: "Rara Visual", price: 25000, img: "1493863641943-9b68992a8d07" },
    { title: "E-Book: Panduan Memulai Bisnis Online", cat: "E-Book", seller: "Bayu Setiawan", price: 75000, img: "1544716278-ca5e3f4abd8c" },
    { title: "Course: Edit Foto Profesional Lightroom", cat: "Course", seller: "Studio Lensa", price: 150000, img: "1502920917128-1aa500764cbd" },
    { title: "Template Skripsi Format APA Lengkap", cat: "Template Akademik", seller: "Dina Akademia", price: 35000, img: "1456513080510-7bf3a84b82f8" },
    { title: "Font Bundle: Display Sans Serif Modern", cat: "Font & Typography", seller: "Tokotype Lab", price: 45000, img: "1561070791-2526d30994b5" },
    { title: "Mockup Kemasan Produk PSD Premium", cat: "Template Desain", seller: "Kreatif Co", price: 60000, img: "1600508774634-4e11d34730e2" },
    { title: "AI Prompt Pack: 500 Prompt Marketing", cat: "AI Prompt Pack", seller: "Nadia AI", price: 30000, img: "1620712943543-bcc4688e7485" }
  ];

  var TESTI = [
    { q: "File langsung ke email setelah bayar QRIS. Nggak perlu nunggu admin, ini yang aku cari dari dulu.", name: "Sasha W.", role: "Content Creator", av: "1562904403-a5106bef8319" },
    { q: "Jual preset di Prodig jadi penghasilan pasif. Upload sekali, cuan terus tiap minggu.", name: "Rio Ananda", role: "Fotografer", av: "1559732658-9ef4bc86cfcd" },
    { q: "Template skripsinya rapi banget dan sesuai format kampus. Hemat waktu berhari-hari.", name: "Putri M.", role: "Mahasiswa", av: "1613447895590-97f008b7fff3" },
    { q: "Pembayaran lokal, harga ramah, dan semua bahasa Indonesia. Akhirnya marketplace yang ngerti UMKM.", name: "Hendra K.", role: "Pemilik UMKM", av: "1546567850-8a49d669d37a" },
    { q: "Dashboard kreatornya jelas, withdraw cepat. Sudah 200+ penjualan dalam 3 bulan.", name: "Galih Pratama", role: "Desainer Grafis", av: "1632635604193-e46310cd411b" }
  ];

  var rupiah = function (n) { return "Rp " + n.toLocaleString("id-ID"); };

  /* ---------- render categories ---------- */
  var catGrid = document.getElementById("catGrid");
  if (catGrid) {
    CATEGORIES.forEach(function (c, i) {
      var a = document.createElement("a");
      a.href = "#produk";
      a.className = "cat reveal";
      a.style.setProperty("--rd", (i % 4) * 0.06 + "s");
      a.innerHTML = '<span class="cat-ico">' + svg(ICON[c.icon]) + "</span><span>" + c.label + "</span>";
      catGrid.appendChild(a);
    });
  }

  /* ---------- render products ---------- */
  var prodGrid = document.getElementById("prodGrid");
  if (prodGrid) {
    PRODUCTS.forEach(function (p, i) {
      var el = document.createElement("article");
      el.className = "prod reveal";
      el.style.setProperty("--rd", (i % 4) * 0.07 + "s");
      el.innerHTML =
        '<div class="thumb" style="background-image:url(\'' + U(p.img, 600) + "')\">" +
          '<span class="chip">' + p.cat + "</span>" +
        "</div>" +
        '<div class="body">' +
          '<div class="seller">oleh <b>' + p.seller + "</b></div>" +
          "<h3>" + p.title + "</h3>" +
          '<div class="foot">' +
            '<span class="price">' + rupiah(p.price) + "</span>" +
            '<button class="buy">Beli Sekarang</button>' +
          "</div>" +
        "</div>";
      prodGrid.appendChild(el);
    });
  }

  /* ---------- render testimonials (duplicated for seamless marquee) ---------- */
  var marquee = document.getElementById("marquee");
  if (marquee) {
    var build = function (t) {
      return '<div class="quote">' +
        '<div class="qstars">★★★★★</div>' +
        "<p>“" + t.q + "”</p>" +
        '<div class="who">' +
          '<span class="av" style="background-image:url(\'' + U(t.av, 100) + "&crop=faces')\"></span>" +
          "<div><b>" + t.name + "</b><small>" + t.role + "</small></div>" +
        "</div>" +
      "</div>";
    };
    var html = TESTI.map(build).join("");
    marquee.innerHTML = html + html; // duplicate => loops seamlessly at -50%
  }

  /* ---------- navbar scroll state ---------- */
  var nav = document.getElementById("nav");
  var onScroll = function () {
    if (window.scrollY > 20) nav.classList.add("scrolled");
    else nav.classList.remove("scrolled");
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- mobile menu ---------- */
  var toggle = document.getElementById("navToggle");
  var links = document.getElementById("navLinks");
  if (toggle && links) {
    toggle.addEventListener("click", function () { links.classList.toggle("open"); });
    links.addEventListener("click", function (e) {
      if (e.target.closest("a")) links.classList.remove("open");
    });
  }

  /* ---------- scroll reveal ---------- */
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (en.isIntersecting) {
        en.target.classList.add("in");
        if (en.target.querySelector(".count") || en.target.classList.contains("count")) {
          // handled by counter observer separately
        }
        io.unobserve(en.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  document.querySelectorAll(".reveal").forEach(function (el) { io.observe(el); });

  /* ---------- animated counters ---------- */
  var prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var countIO = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      var el = en.target;
      var to = parseFloat(el.getAttribute("data-to"));
      var decimal = el.getAttribute("data-decimal");
      if (prefersReduced) {
        el.textContent = decimal ? (to / Math.pow(10, +decimal)).toFixed(+decimal) : Math.round(to).toLocaleString("id-ID");
        countIO.unobserve(el);
        return;
      }
      var start = performance.now();
      var dur = 1600;
      var tick = function (now) {
        var p = Math.min((now - start) / dur, 1);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = to * eased;
        if (decimal) {
          el.textContent = (val / Math.pow(10, +decimal)).toFixed(+decimal);
        } else {
          el.textContent = Math.round(val).toLocaleString("id-ID");
        }
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      countIO.unobserve(el);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll(".count").forEach(function (el) { countIO.observe(el); });

  /* ---------- magnetic buttons ---------- */
  if (!prefersReduced && window.matchMedia("(hover:hover)").matches) {
    document.querySelectorAll(".magnetic").forEach(function (btn) {
      var strength = 0.32;
      btn.addEventListener("mousemove", function (e) {
        var r = btn.getBoundingClientRect();
        var x = e.clientX - r.left - r.width / 2;
        var y = e.clientY - r.top - r.height / 2;
        btn.style.transform = "translate(" + x * strength + "px," + y * strength + "px)";
      });
      btn.addEventListener("mouseleave", function () { btn.style.transform = ""; });
    });
  }

  /* ---------- hero parallax (mouse + scroll) on float cards ---------- */
  var hero = document.getElementById("hero");
  var visual = document.getElementById("heroVisual");
  var depthEls = visual ? [].slice.call(visual.querySelectorAll("[data-depth]")) : [];
  var mx = 0, my = 0, sy = 0;
  if (!prefersReduced && visual) {
    hero.addEventListener("mousemove", function (e) {
      var r = hero.getBoundingClientRect();
      mx = (e.clientX - r.left) / r.width - 0.5;
      my = (e.clientY - r.top) / r.height - 0.5;
    });
    hero.addEventListener("mouseleave", function () { mx = 0; my = 0; });
    var raf = function () {
      depthEls.forEach(function (el) {
        var d = parseFloat(el.getAttribute("data-depth")) || 20;
        el.style.transform = "translate3d(" + (mx * d) + "px," + (my * d * 0.7 + sy * d * 0.15) + "px,0)";
      });
      requestAnimationFrame(raf);
    };
    window.addEventListener("scroll", function () { sy = Math.min(window.scrollY / 40, 14); }, { passive: true });
    requestAnimationFrame(raf);
  }

  /* ---------- particle canvas ---------- */
  var canvas = document.getElementById("particles");
  if (canvas && !prefersReduced) {
    var ctx = canvas.getContext("2d");
    var W, H, dots, dpr;
    var accent = function () {
      var v = getComputedStyle(document.documentElement).getPropertyValue("--acc-rgb").trim();
      return v || "212,175,55";
    };
    var resize = function () {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = canvas.clientWidth; H = canvas.clientHeight;
      canvas.width = W * dpr; canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      var count = Math.min(70, Math.floor(W * H / 17000));
      dots = [];
      for (var i = 0; i < count; i++) {
        dots.push({
          x: Math.random() * W, y: Math.random() * H,
          vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25,
          r: Math.random() * 1.8 + 0.6
        });
      }
    };
    var draw = function () {
      if (canvas.parentElement && hero.getAttribute("data-bg") !== "particles" && hero.getAttribute("data-bg") !== "all") {
        ctx.clearRect(0, 0, W, H);
        requestAnimationFrame(draw);
        return;
      }
      ctx.clearRect(0, 0, W, H);
      var rgb = accent();
      for (var i = 0; i < dots.length; i++) {
        var d = dots[i];
        d.x += d.vx; d.y += d.vy;
        if (d.x < 0 || d.x > W) d.vx *= -1;
        if (d.y < 0 || d.y > H) d.vy *= -1;
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(" + rgb + ",0.55)";
        ctx.fill();
        for (var j = i + 1; j < dots.length; j++) {
          var d2 = dots[j];
          var dx = d.x - d2.x, dy = d.y - d2.y;
          var dist = dx * dx + dy * dy;
          if (dist < 13000) {
            ctx.beginPath();
            ctx.moveTo(d.x, d.y);
            ctx.lineTo(d2.x, d2.y);
            ctx.strokeStyle = "rgba(" + rgb + "," + (0.16 * (1 - dist / 13000)) + ")";
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(draw);
    };
    resize();
    window.addEventListener("resize", resize);
    requestAnimationFrame(draw);
  }
})();
