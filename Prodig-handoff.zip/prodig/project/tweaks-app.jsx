/* Tweaks app — re-themes the vanilla page live via CSS vars + data attrs. */
const { useEffect } = React;

const ACCENTS = {
  Gold:    ["#e7d295", "#E5C158", "#D4AF37", "#B8941F"],
  Emerald: ["#6ee7b7", "#34d399", "#10b981", "#059669"],
  Biru:    ["#7dd3fc", "#38bdf8", "#0ea5e9", "#0284c7"],
  Ungu:    ["#c4b5fd", "#a78bfa", "#8b5cf6", "#7c3aed"]
};

const MOTION = { Halus: 0.6, Hidup: 1, Maksimal: 1.35 };
const BG_MAP = { Orb: "orbs", Grid: "grid", Partikel: "particles", Semua: "all" };

function hexToRgb(hex) {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return (n >> 16) + "," + ((n >> 8) & 255) + "," + (n & 255);
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": ["#e7d295", "#E5C158", "#D4AF37", "#B8941F"],
  "motion": "Maksimal",
  "heroBg": "Semua",
  "mockups": true
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    const r = document.documentElement;
    const a = t.accent || ACCENTS.Gold;
    r.style.setProperty("--acc-300", a[0]);
    r.style.setProperty("--acc-400", a[1]);
    r.style.setProperty("--acc-500", a[2]);
    r.style.setProperty("--acc-600", a[3]);
    r.style.setProperty("--acc-rgb", hexToRgb(a[2]));
  }, [t.accent]);

  useEffect(() => {
    document.documentElement.style.setProperty("--motion", MOTION[t.motion] || 1);
  }, [t.motion]);

  useEffect(() => {
    const hero = document.getElementById("hero");
    if (hero) hero.setAttribute("data-bg", BG_MAP[t.heroBg] || "all");
  }, [t.heroBg]);

  useEffect(() => {
    const hero = document.getElementById("hero");
    if (hero) hero.setAttribute("data-mockups", t.mockups ? "on" : "off");
  }, [t.mockups]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Warna" />
      <TweakColor
        label="Aksen"
        value={t.accent}
        options={[ACCENTS.Gold, ACCENTS.Emerald, ACCENTS.Biru, ACCENTS.Ungu]}
        onChange={(v) => setTweak("accent", v)}
      />
      <TweakSection label="Animasi" />
      <TweakRadio
        label="Intensitas"
        value={t.motion}
        options={["Halus", "Hidup", "Maksimal"]}
        onChange={(v) => setTweak("motion", v)}
      />
      <TweakSection label="Hero" />
      <TweakRadio
        label="Latar"
        value={t.heroBg}
        options={["Orb", "Grid", "Partikel", "Semua"]}
        onChange={(v) => setTweak("heroBg", v)}
      />
      <TweakToggle
        label="Kartu produk melayang"
        value={t.mockups}
        onChange={(v) => setTweak("mockups", v)}
      />
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById("tweaks-root")).render(<App />);
